<?php $__env->startSection('content'); ?>
	<div class="col-md-12">
		<legend>Laravel 5.4 Simple CRUD App | <b>Read Page</b></legend>
		<p><b>Event Name: </b><?php echo e($posts->event); ?></p>
		<p><b>Description: </b><?php echo e($posts->description); ?></p>
		<div class="form-group">
	        <a href="<?php echo e(url('/home')); ?>" class="btn btn-primary" >Back</a>
	    </div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>