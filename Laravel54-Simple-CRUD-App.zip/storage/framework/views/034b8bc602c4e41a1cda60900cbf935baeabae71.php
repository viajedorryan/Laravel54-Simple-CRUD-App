<?php $__env->startSection('content'); ?>
	<div class="col-md-12">
		<legend>Laravel 5.4 Simple CRUD App | <b>Home Page</b></legend>
		<?php if(session('info')): ?>
			<div class=" alert alert-info">
				<center><?php echo e(session('info')); ?></center>
			</div>
		<?php endif; ?>
		<table class="table table-striped table-hover ">
		  <thead>
		    <tr>
		      <th>ID</th>
		      <th>Event</th>
		      <th>Description</th>
		      <th colspan="2"><center>Action</center></th>
		    </tr>
		  </thead>
		  <tbody>
		  	<?php if(count($posts) > 0): ?>
				<?php $__currentLoopData = $posts->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
				      <td><?php echo e($post->id); ?></td>
				      <td><?php echo e($post->event); ?></td>
				      <td><?php echo e($post->description); ?></td>
				      <td colspan="2">
				      	<center>
					      	<a href='<?php echo e(url("/read/{$post->id}")); ?>' class="label label-primary">Read</a>
					      	|
					      	<a href='<?php echo e(url("/update/{$post->id}")); ?>' class="label label-success">Update</a>
					      	|
					      	<a href='<?php echo e(url("/delete/{$post->id}")); ?>' class="label label-danger">Delete</a>
					    </center>
				      </td>
				    </tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		  	<?php endif; ?>
		  </tbody>
		</table> 
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>